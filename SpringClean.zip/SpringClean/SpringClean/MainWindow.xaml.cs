﻿using System.Diagnostics;
using System.Formats.Tar;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SpringClean
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CleanTemp();
            CleanObsoleteWindowsDownload();
        }

        public void CleanTemp()
        {
           
            const string TEMP_PATH = @"C:\Users\User\AppData\Local\Temp";
            System.IO.DirectoryInfo di = new DirectoryInfo(TEMP_PATH);

            foreach (FileInfo file in di.GetFiles())
            {
                try
                {
                    file.Delete();
                }
                catch 
                {
                    Console.WriteLine(file); 
                }
                
            }
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                try
                {
                    dir.Delete(true);
                }
                catch
                { 
                    Console.WriteLine(dir);
                }
                
            }
        }

        public void CleanObsoleteWindowsDownload()
        {
      
            const string WINDOWSOBSOLETEDOWNLOADS_PATH = @"C:\Windows\SoftwareDistribution\Download";
            System.IO.DirectoryInfo di = new DirectoryInfo(WINDOWSOBSOLETEDOWNLOADS_PATH);

            foreach (FileInfo file in di.GetFiles())
            {
                try
                {
                    file.Delete();
                }
                catch
                {
                    Console.WriteLine(file);
                }

            }
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                try
                {
                    dir.Delete(true);
                }
                catch
                {
                    Console.WriteLine(dir);
                }

            }
        }
    }

   
}