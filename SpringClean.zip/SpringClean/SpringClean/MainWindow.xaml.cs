﻿
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;


namespace SpringClean
{
    //To skip the dialog if you really want to empty the recycle bin
    enum RecycleFlags : uint
    {
        SHRB_NOCONFIRMATION = 0x00000001,
        SHRB_NOPROGRESSUI = 0x00000002,
        SHRB_NOSOUND = 0x00000004
    }
    //Hiii i see your checking out my code... why tho theres not much here. Thanks anyway i guess
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CleanTemp();
            deleteLeftoverWinUpdate();

           
        [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
            static extern uint SHEmptyRecycleBin(IntPtr hwnd, string pszRootPath, RecycleFlags dwFlags);
            uint IsSuccess = SHEmptyRecycleBin(IntPtr.Zero, null, RecycleFlags.SHRB_NOCONFIRMATION);
        }

        public void CleanTemp()
        {
            //not C:Temp!!
            const string TEMP_PATH = @"C:\Users\User\AppData\Local\Temp";
            System.IO.DirectoryInfo di = new DirectoryInfo(TEMP_PATH);

            foreach (FileInfo file in di.GetFiles())
            {
                try
                {
                    file.Delete();
                }
                catch
                {
                    Console.WriteLine(file);
                }

            }
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                try
                {
                    dir.Delete(true);
                }
                catch
                {
                    Console.WriteLine(dir);
                }

            }
        }

        public void deleteLeftoverWinUpdate()
        {
            //Why does windows keep this?? holy Microslop :\
            const string WINDOWSOBSOLETEDOWNLOADS_PATH = @"C:\Windows\SoftwareDistribution\Download";
            System.IO.DirectoryInfo di = new DirectoryInfo(WINDOWSOBSOLETEDOWNLOADS_PATH);

            foreach (FileInfo file in di.GetFiles())
            {
                try
                {
                    file.Delete();
                }
                catch
                {
                    Console.WriteLine(file);
                }

            }
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                try
                {
                    dir.Delete(true);
                }
                catch
                {
                    Console.WriteLine(dir);
                }

            }
        }
        public void EmptyBin()
        {
          
        }

    }
}

   
