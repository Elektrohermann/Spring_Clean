﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SpringClean
{
    /// <summary>
    /// Interaktionslogik für Config_Window.xaml
    /// </summary>
    public partial class Config_Window : Window
    {
        public Config_Window()
        {
            InitializeComponent();
        }

        private void CheckBox_CheckedChanged(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("Here");
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("Here");
        }
    }
}
